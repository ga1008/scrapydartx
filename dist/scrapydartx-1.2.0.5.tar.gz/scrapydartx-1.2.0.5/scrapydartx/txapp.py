# this file is used to start scrapydartx with twistd -y
from scrapydart import get_application
application = get_application()
