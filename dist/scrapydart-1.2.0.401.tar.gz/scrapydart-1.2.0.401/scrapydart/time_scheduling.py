import os
import time
import json
import datetime
import threading
import requests
import psutil
from twisted.logger import Logger
from .config import Config
from .mysql_orm import GetData
from .models_all import SpiderScheduleModel
from apscheduler.schedulers.background import BackgroundScheduler

hightest_level = {}


class TimeSchedule:

    def __init__(self, lock, host='127.0.0.1', port='6800'):
        config = Config()
        self.user_name = config.get('auth_username')
        self.user_password = config.get('auth_password')
        self.start_time = time.strftime("%Y %m %d %H %M %S", time.localtime())
        self.host = host
        self.port = port
        self.server_port = 'http://{}:{}/'.format(self.host, self.port)
        self.timerank_url = os.path.join(self.server_port, 'timerank.json?index=100&un={}&pwd={}'.format(self.user_name, self.user_password))
        self.schedule_post_url = 'http://{}:{}/schedule.json'.format(self.host, self.port)
        self.listproject_url = 'http://{}:{}/listprojects.json'.format(self.host, self.port)
        self.projects = self.list_projects()
        self.spider_task_dic = dict()
        self.db_lock = lock
        self.ts_lock = threading.Lock()
        self.CPU_THRESHOLD = 93
        self.MEMORY_THRESHOLD = 96
        self.schedule_logger = Logger(namespace='- Scheduler -')
        self.scheduler = BackgroundScheduler()

    def run(self):
        time.sleep(3)
        self.schedule_logger.info('scheduler is running')
        count = 1
        while True:

            # y, m, d, H, M, S = [int(x) for x in self.start_time.split(' ')]
            # s = "(datetime.datetime.now() - datetime.datetime({},{},{}, {},{},{})).total_seconds()".format(y,m,d, H,M,S)
            # secs = eval(s)
            # m, s = divmod(secs, 60)
            # h, m = divmod(m, 60)
            # runtime = "%d:%02d:%s" % (h, m, round(s))
            # self.schedule_logger.info('The {}th Round of Inspection (system runtime: {})'.format(count, runtime))

            self.task_scheduler()
            # self.ap_scheduler()
            # if count != 1:
            #     try:
            #         self.ts_lock.acquire(blocking=True)
            #         spider_schedule_dic = self.spider_task_dic
            #         self.ts_lock.release()
            #         spider_schedule_lis = ['\n%s: [%s]' % (x, spider_schedule_dic.get(x)) for x in spider_schedule_dic]
            #         spider_schedule_str = ','.join(spider_schedule_lis)
            #         log_str = "spider schedule: {}".format(spider_schedule_str)
            #         self.schedule_logger.info(log_str)
            #     except:
            #         self.schedule_logger.info('It looks like there has no spider been scheduled')
            #         pass
            time.sleep(10)
            count += 1

    def task_scheduler(self):
        db = GetData()
        self.ts_lock.acquire(blocking=True)
        self.db_lock.acquire()
        db_result = db.get_result(model=SpiderScheduleModel, fields=['project', 'spider', 'schedule', 'args', 'status'])
        self.db_lock.release()
        self.ts_lock.release()
        schedule_list_raw = [
            {'project': x.project, 'spider': x.spider, 'schedule': x.schedule, 'args': x.args, 'status': x.status}
            for x in db_result if int(x.status) != 0
        ] if db_result else []

        if schedule_list_raw:
            for each_schedule in schedule_list_raw:
                project = each_schedule.get('project')
                if project in self.projects:
                    schedule = each_schedule.get('schedule')
                    try:
                        schedule = json.loads(schedule)
                    except:
                        schedule = eval(schedule)
                    try:
                        next_time_sep = self.cal_time_sep(**schedule)
                        each_schedule['schedule'] = next_time_sep
                        item = '{}-{}'.format(each_schedule['project'], each_schedule['spider'])
                        # spider_task_dic = dict()
                        self.ts_lock.acquire(blocking=True)
                        if self.spider_task_dic.get(item) != 'waiting':
                            self.spider_task_dic[item] = 'waiting'
                            t = threading.Thread(target=self.poster, args=(each_schedule, ))
                            try:
                                t.start()
                            except Exception as APError:
                                self.schedule_logger.warn('no new jobs : {}'.format(APError))
                        self.ts_lock.release()
                    except ValueError:
                        self.schedule_logger.error('spider runtime schedule error, please check the database')
        else:
            self.schedule_logger.info('No Scheduled Spider in Database')

    def poster(self, dic):
        status = int(dic.pop('status'))
        project = dic.get('project')
        spider = dic.get('spider')
        job_str = " %s-%s " % (project, spider)
        args = dic.get('args')
        if args:
            args = eval(args)
        wait_time = dic.get('schedule')
        post_url = self.schedule_post_url
        if project and spider:
            data = {'project': project, 'spider': spider, 'un': self.user_name, 'pwd': self.user_password}
            if args:
                data.update(args)
            item = '{}-{}'.format(project, spider)
            self.schedule_logger.info('job {} is waiting, countdown {}s'.format(item, wait_time))
            time.sleep(wait_time - 1)
            another_wait_time = 0
            spider_runtime_avg = self.spider_runtime(req_spider=spider)
            if int(status) == 1:
                while not self.is_system_ok():
                    self.schedule_logger.warning('system is fully functioning, wait another 2 seconds to post schedule')
                    time.sleep(3)
                    another_wait_time += 2
                    if another_wait_time >= (wait_time - spider_runtime_avg):
                        self.schedule_logger.warning('wait too long, cancel the job %s' % job_str)
                        return None
            self.schedule_logger.info('job {} start'.format(item))
            res = json.loads(requests.post(url=post_url, data=data).content)
            if int(status) == 3:
                global hightest_level
                self.db_lock.acquire()
                self.ts_lock.acquire()
                hightest_level.add(res.get('jobid'))
                self.ts_lock.release()
                self.db_lock.release()
            log_str = "post result: \n\t{} >>> status: {}, job_id: {}".format(item, res.get('status'), res.get('jobid'))
            self.schedule_logger.info(log_str)
            spider_status = res.get('status')
            if spider_status != 'ok':
                spider_status = 'error'
            self.ts_lock.acquire(blocking=True)
            self.spider_task_dic[item] = spider_status
            self.ts_lock.release()
        else:
            self.schedule_logger.error('job project: {}, spider: {} post fail!'.format(project, spider))

    def ap_scheduler(self):
        db = GetData()
        self.db_lock.acquire()
        db_result = db.get_result(model=SpiderScheduleModel, fields=['project', 'spider', 'schedule', 'args', 'status'])
        self.db_lock.release()
        schedule_list_raw = [
            {'project': x.project, 'spider': x.spider, 'schedule': x.schedule, 'args': x.args}
            for x in db_result if int(x.status) == 1
        ]
        for each_schedule in schedule_list_raw:
            schedule = each_schedule.get('schedule')
            schedule = eval(schedule)
            schedule_dic = self.ap_shedule_type(schedule)
            try:
                item = '{}-{}'.format(each_schedule['project'], each_schedule['spider'])
                self.ts_lock.acquire(blocking=True)
                if self.spider_task_dic.get(item) != 'waiting':
                    self.spider_task_dic[item] = 'waiting'
                    schedule_type = schedule_dic.get('schedule_type')
                    run_time = schedule_dic.get('schedules')
                    if schedule_type == 'date':
                        self.scheduler.add_job(func=self.ap_poster, trigger=schedule_type, run_date=run_time, args=[each_schedule])
                    else:
                        self.scheduler.add_job(func=self.ap_poster, trigger=schedule_type, args=[each_schedule], **run_time)
                self.ts_lock.release()
            except ValueError as E:
                self.schedule_logger.error('spider runtime schedule error, please check the database: {}'.format(E))

        self.scheduler.start()

    def ap_shedule_type(self, schedules):
        dic = dict()
        schedule_type = 'interval'

        is_date = False
        for dt in schedules:
            if schedules.get(dt).isdigit():
                schedule_type = 'date'
                is_date = True
        dic['schedule_type'] = schedule_type
        if is_date:
            schedule_dic = {'years': int(time.strftime("%Y", time.localtime())),
                            'months': int(time.strftime("%m", time.localtime())),
                            'days': int(time.strftime("%d", time.localtime())),
                            'hours': int(time.strftime("%H", time.localtime())),
                            'minutes': int(time.strftime("%M", time.localtime())),
                            'seconds': int(time.strftime("%S", time.localtime())),
                            }
            schedule_dic.update(schedules)
            schedule_lis = [str(x) for x in [*schedule_dic.values()]]
            schedule_res = '-'.join(schedule_lis[:3]) + ' ' + ':'.join(schedule_lis[3:])
        else:
            schedule_res = {x.rstrip('s') + 's': int(schedules.get(x).split('/')[-1]) for x in schedules}

        dic['schedules'] = schedule_res
        return dic

    def ap_poster(self, dic):
        project = dic.get('project')
        spider = dic.get('spider')
        job_str = " %s-%s " % (project, spider)
        args = dic.get('args')
        if args:
            args = eval(args)
        post_url = self.schedule_post_url
        if project and spider:
            data = {'project': project, 'spider': spider, 'un': self.user_name, 'pwd': self.user_password}
            if args:
                data.update(args)
            item = '{}-{}'.format(project, spider)
            self.schedule_logger.info('job {} start'.format(item))
            res = json.loads(requests.post(url=post_url, data=data).content)
            log_str = "post result: \n\t{} >>> status: {}, job_id: {}".format(item, res.get('status'), res.get('jobid'))
            self.schedule_logger.info(log_str)
            spider_status = res.get('status')
            if spider_status != 'ok':
                spider_status = 'error'
            self.ts_lock.acquire(blocking=True)
            self.spider_task_dic[item] = spider_status
            self.ts_lock.release()
        else:
            self.schedule_logger.error('job project: {}, spider: {} post fail!'.format(project, spider))

    def spider_runtime(self, req_spider=''):
        res = requests.get(url=self.timerank_url)
        spider_list = list()
        spiders_dic = dict()
        if res:
            rank_list = json.loads(res.content).get('ranks')
            if rank_list:
                for each_spider in rank_list:
                    spider_name = each_spider.get('spider')
                    runtime = each_spider.get('time')
                    if runtime:
                        runtime_lis = runtime.split(":")
                        runtime = int(
                            runtime_lis[0]) * 60 * 60 + int(runtime_lis[1]) * 60 + int(runtime_lis[2])
                        spider_list.append([spider_name, runtime])
                        if not spiders_dic.get(spider_name):
                            spiders_dic[spider_name] = list()
                            spiders_dic[spider_name].append(runtime)
                        else:
                            spiders_dic[spider_name].append(runtime)
        if req_spider and spiders_dic.get(req_spider):
            return sum(spiders_dic.get(req_spider))//len(spiders_dic.get(req_spider))
        elif req_spider and not spiders_dic.get(req_spider):
            return 0
        return spider_list

    def list_projects(self):
        res = requests.get(url=self.listproject_url)
        projects = {}
        if res:
            projects_list = json.loads(res.content).get('projects')
            if projects_list:
                projects = set(projects_list)
        return projects

    def cal_time_sep(self,
            year='*',
            month='*',
            day='*',
            week='*',
            hour='*',
            minute='*',
            second='*',
            ):
        """
            "%Y-%m-%d %H:%M:%S %w"

        """

        y = int(time.strftime("%Y", time.localtime()))
        if year != '*' and '*' in year:
            y = int(year.split('/')[-1]) + y
        elif year.isdigit():
            y = int(year)

        if week == '*':
            m = int(time.strftime("%m", time.localtime()))
            if month != '*' and '*' in month:
                m_raw = int(month.split('/')[-1])
                if m_raw >= 12:
                    raise ValueError('month value is too large, please set the year instead')
                m = m_raw + m
                if m > 12:
                    y += m // 12
                    m = m % 12
            elif month.isdigit():
                m = int(month)

            days_in_this_month = self.how_many_days_in_this_month(y, m)
            d = int(time.strftime("%d", time.localtime()))
            if day != '*' and '*' in day:
                d_raw = int(day.split('/')[-1])
                if d_raw > days_in_this_month:
                    raise ValueError('day value is too large, please set the month or the year instead')
                d = d_raw + d
                if d > days_in_this_month:
                    d = d - days_in_this_month
                    m += 1
                    if m > 12:
                        y += 1
                        m = m - 12
            elif day.isdigit():
                d = int(day)

            days_in_this_month = self.how_many_days_in_this_month(y, m)
            H = int(time.strftime("%H", time.localtime()))
            if hour != '*' and '*' in hour:
                H_raw = int(hour.split('/')[-1])
                if H_raw > 24:
                    raise ValueError('hour value is too large, please set the day instead')
                H = H_raw + H
                if H >= 24:
                    H = H - 24
                    d += 1
                    if d > days_in_this_month:
                        d = d - days_in_this_month
                        m += 1
                        if m > 12:
                            y += 1
                            m = m - 12
            elif hour.isdigit():
                H = int(hour)

            days_in_this_month = self.how_many_days_in_this_month(y, m)
            M = int(time.strftime("%M", time.localtime()))
            if minute != '*' and '*' in minute:
                M_raw = int(minute.split('/')[-1])
                if M_raw > 60:
                    raise ValueError('minute value is too large, please set the hour instead')
                M = M_raw + M
                if M >= 60:
                    M = M - 60
                    H += 1
                    if H >= 24:
                        H = H - 24
                        d += 1
                        if d > days_in_this_month:
                            d = d - days_in_this_month
                            m += 1
                            if m > 12:
                                y += 1
                                m = m - 12
            elif minute.isdigit():
                M = int(minute)

            days_in_this_month = self.how_many_days_in_this_month(y, m)
            S = int(time.strftime("%S", time.localtime()))
            if second != '*' and '*' in second:
                S_raw = int(second.split('/')[-1])
                if S_raw > 60:
                    raise ValueError('second value is too large, please set the minute instead')
                S = S_raw + S
                if S >= 60:
                    S = S - 60
                    M += 1
                    if M >= 60:
                        M = M - 60
                        H += 1
                        if H >= 24:
                            H = H - 24
                            d += 1
                            if d > days_in_this_month:
                                d = d - days_in_this_month
                                m += 1
                                if m > 12:
                                    y += 1
                                    m = m - 12
            elif second.isdigit():
                S = int(second)
            time_sep = eval("(datetime.datetime({},{},{}, {},{},{}) - datetime.datetime.now()).total_seconds()".format(y,m,d, H,M,S))

        else:
            week_in_this_year = int(time.strftime("%U", time.localtime()))
            w = int(time.strftime("%w", time.localtime()))
            if '*' in week:
                w_raw = int(week.split('/')[-1])
                if w_raw >= 7:
                    raise ValueError('week value is too large, please set the day or the month instead')
                if w_raw < w:
                    week_in_this_year += 1
                w = w_raw
                if week_in_this_year > 53:
                    y += 1
                    week_in_this_year = week_in_this_year - 53

            elif week.isdigit():
                w = int(week)
                if int(week) < w:
                    week_in_this_year += 1

            H = int(time.strftime("%H", time.localtime()))
            if hour != '*' and '*' in hour:
                H_raw = int(hour.split('/')[-1])
                if H_raw >= 24:
                    raise ValueError('hour value is too large, please set the day instead')
                H = H_raw + H
                if H >= 24:
                    H = H - 24
                    w += 1
                    if w >= 7:
                        w = w - 7
                        week_in_this_year += 1
                        if week_in_this_year > 53:
                            y += 1
                            week_in_this_year = week_in_this_year - 53
            elif hour.isdigit():
                H = int(hour)

            M = int(time.strftime("%M", time.localtime()))
            if minute != '*' and '*' in minute:
                M_raw = int(minute.split('/')[-1])
                if M_raw >= 60:
                    raise ValueError('minute value is too large, please set the hour instead')
                M = M_raw + M
                if M >= 60:
                    M = M - 60
                    H += 1
                    if H >= 24:
                        H = H - 24
                        w += 1
                        if w > 7:
                            w = w - 7
                            week_in_this_year += 1
                            if week_in_this_year > 53:
                                y += 1
                                week_in_this_year = week_in_this_year - 53
            elif minute.isdigit():
                M = int(minute)

            S = int(time.strftime("%S", time.localtime()))
            if second != '*' and '*' in second:
                S_raw = int(second.split('/')[-1])
                if S_raw >= 60:
                    raise ValueError('second value is too large, please set the minute instead')
                S = S_raw + S
                if S >= 60:
                    S = S - 60
                    M += 1
                    if M >= 60:
                        M = M - 60
                        H += 1
                        if H >= 24:
                            H = H - 24
                            w += 1
                            if w > 7:
                                w = w - 7
                                week_in_this_year += 1
                                if week_in_this_year > 53:
                                    y += 1
                                    week_in_this_year = week_in_this_year - 53
            elif second.isdigit():
                S = int(second)
            if S >= 60:
                S = S - 60
                M += 1
                if M >= 60:
                    M = M - 60
                    H += 1
                    if H >= 24:
                        H = H - 24
                        d += 1
                        if d > days_in_this_month:
                            d = d - days_in_this_month
                            m += 1
                            if m > 12:
                                y += 1
                                m = m - 12
            m, d = self.get_month_and_days_by_week(year=y, week_in_this_year=week_in_this_year, week=w)
            time_sep = eval("(datetime.datetime({},{},{}, {},{},{}) - datetime.datetime.now()).total_seconds()".format(y, m, d, H, M, S))

        return time_sep

    def get_month_and_days_by_week(self, year, week_in_this_year, week):
        days = week_in_this_year * 7 + week
        if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
            Fe = 29
        else:
            Fe = 28
        month_lis = [31, Fe, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        month_count = 1
        days_count = 0
        for month_days in month_lis:
            days = days - month_days
            if days > 0:
                month_count += 1
            elif days == 0:
                days_count = 0
                month_count += 1
                break
            else:
                days_count = days + month_days
                break
        return [month_count, days_count]

    def how_many_days_in_this_month(self, y, m):
        if m in (1, 3, 5, 7, 8, 10, 12):
            days = 31
        elif m in (4, 6, 9, 11):
            days = 30
        else:
            if (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0):
                days = 29
            else:
                days = 28
        return days

    def is_system_ok(self):
        is_pass = True
        cpu_list = psutil.cpu_percent(interval=1, percpu=True)
        memory_percent = psutil.virtual_memory().percent
        if cpu_list and memory_percent:
            is_cpu_ok = True
            if min(cpu_list) > self.CPU_THRESHOLD:
                is_cpu_ok = False
            is_memo_ok = True
            if memory_percent > self.MEMORY_THRESHOLD:
                is_memo_ok = False
            if not is_cpu_ok or not is_memo_ok:
                is_pass = False
        return is_pass


if __name__ == "__main__":
    # insert_schedule_into_database(values=['P1', 'spider_2', "{'second': '*/30'}", '1'])
    # time.sleep(1)
    TS = TimeSchedule()
    # m, d = TS.get_month_and_days_by_week(year=2020, week_in_this_year=20, week=3)
    # 

    # time_sep = TS.cal_time_sep(second='*/50')

    # print(TS.is_system_ok())

    TS.run()
