from importlib import reload
from .sqlite_orm import GetData
from .sqlite_model import SpiderMonitor, SpiderScheduleModel, TerminatedSpider, UnormalSpider
from scrapyd_api import ScrapydAPI
from twisted.logger import Logger
from .config import Config
import threading
import signal
import random
import os
import datetime
import time
import json
import requests
import numpy as np


class RuntimeCalculator:
    def __init__(self, lock, addr='', port=''):
        config = Config()
        self.lock = lock
        self.user_name = config.get('auth_username')
        self.user_password = config.get('auth_password')
        self.db = GetData()
        self.runtime_log = Logger(namespace='- Runtime Collector -')
        self.terminator_log = Logger(namespace='- TERMINATOR -')
        self.sep_time = 5 * 60  # 每次收集时间间隔 5分钟
        self.terminator_scan_sep = 20
        self.standard_deviation_extend_times = 4   # 方差倍数，数值越大越容易被定为正常运行时间
        if not addr:
            addr = '127.0.0.1'
        if not port:
            port = '6800'
        self.server_port = 'http://{}:{}/'.format(addr, port)
        self.scrapyd = ScrapydAPI(self.server_port)
        self.timerank_url = os.path.join(self.server_port, 'timerank.json?index=100&un={}&pwd={}'.format(self.user_name, self.user_password))
        self.jobs_url = os.path.join(self.server_port, 'listjobs.json?un={}&pwd={}'.format(self.user_name, self.user_password))
        self.lock.acquire()
        data = self.db.get(model_name='SpiderMonitor', key_list=['spider', 'runtime'])
        self.lock.release()
        self.spider_list = [{x.spider: x.runtime} for x in data] if data else []
        self.spider_dic = self.list_the_spiders(self.spider_list)
        self.lock.acquire()
        spider_data = self.db.get(model_name='UnormalSpider', key_list=['spider'])
        self.lock.release()
        self.unormal_spiders = set([x.spider for x in spider_data]) if spider_data else {}

    def list_the_spiders(self, spider_list):
        dic = dict()
        if spider_list:
            for spider_dic in spider_list:
                spider_name = [x for x in spider_dic.keys()][0]
                runtime = int([x for x in spider_dic.values()][0])
                if dic.get(spider_name):
                    dic[spider_name].append(runtime)
                else:
                    dic[spider_name] = list()
                    dic[spider_name].append(runtime)
        return dic

    def unusual_spider(self, name_of_spider, runtime_of_spider, save_to_database=True):
        over_time = -1000
        if self.spider_dic:
            time_list = self.spider_dic.get(name_of_spider)
            if time_list:
                std = np.std(time_list)
                avg = sum(time_list) / len(time_list)
                over_time = runtime_of_spider - (std * self.standard_deviation_extend_times + avg)
                if over_time > 0:
                    if save_to_database:
                        if name_of_spider not in self.unormal_spiders:
                            self.lock.acquire()
                            self.db.add(model=UnormalSpider, add_dic={'spider': name_of_spider})
                            self.lock.release()
        return over_time

    def save_spider_runtime(self):
        time.sleep(3)
        while True:
            save_sta = False
            for s_lis in self.runtime_monitor():
                if s_lis:
                    spider_name, runtime = s_lis
                    if self.unusual_spider(spider_name, runtime, save_to_database=False) <= 0:
                        self.database_limit_ctrl(
                                model_name='SpiderMonitor',
                                filter_name='spider',
                                filter_value=spider_name,
                                limit=1000
                        )
                        self.lock.acquire()
                        self.db.add(model=SpiderMonitor, add_dic={'spider': spider_name, 'runtime': runtime})
                        self.lock.release()
                        save_sta = True
            if save_sta:
                self.runtime_log.info('spider runtime saved')
            time.sleep(self.sep_time)

    def database_limit_ctrl(self, model_name, filter_name, filter_value, limit=1000):
        where_field_value = '{},{}'.format(filter_name, filter_value)
        self.lock.acquire(blocking=True)
        res = self.db.get(model_name=model_name, key_list=['id'], filter_dic={filter_name: filter_value})
        self.lock.release()
        if res:
            res = [x.id for x in res]
            res.sort(reverse=True)
            if len(res) > limit:
                if limit > 100:
                    limit = random.randint(100, limit)
                remove_lis = res[limit:]
                for id in remove_lis:
                    self.lock.acquire()
                    self.db.delete_data(model_name=model_name, filter_dic={'id': id})
                    self.lock.release()

    def runtime_monitor(self, req_spider=''):
        res = requests.get(url=self.timerank_url)
        spider_list = list()
        spiders_dic = dict()
        if res:
            rank_list = json.loads(res.content).get('ranks')
            if rank_list:
                for each_spider in rank_list:
                    spider_name = each_spider.get('spider')
                    runtime = each_spider.get('time')
                    if runtime:
                        runtime_lis = runtime.split(":")
                        runtime = int(
                            runtime_lis[0]) * 60 * 60 + int(runtime_lis[1]) * 60 + int(runtime_lis[2])
                        spider_list.append([spider_name, runtime])
                        if not spiders_dic.get(spider_name):
                            spiders_dic[spider_name] = list()
                            spiders_dic[spider_name].append(runtime)
                        else:
                            spiders_dic[spider_name].append(runtime)
        if req_spider and spiders_dic:
            return sum(spiders_dic.get(req_spider))//len(spiders_dic.get(req_spider))
        return spider_list

    def time_format(self, strtime):
        strtime = str(strtime)

        times = [x.strip() for x in strtime.split('d')]
        if len(times) > 1:
            d = int(times[0])
            hms = times[1]
        else:
            d = 0
            hms = times[0]

        h, m, s = [int(x.strip()) for x in hms.split(":") if x and x.strip()]
        seconds = d * 24 * 60 * 60 + h * 60 * 60 + m * 60 + s
        return seconds

    def terminator(self):
        time.sleep(3)
        self.terminator_log.info('Terminator Started')
        while True:
            try:
                res = json.loads(requests.get(url=self.jobs_url).content)
                if res.get('status') == 'ok':
                    running_spiders = res.get('running')
                    if running_spiders:
                        kill_lis = list()
                        for running_spider in running_spiders:
                            project = running_spider.get('project')
                            spider = running_spider.get('spider')
                            job_id = running_spider.get('id')
                            PID = running_spider.get('pid')
                            start_time = running_spider.get('start_time')
                            from .time_scheduling import hightest_level
                            reload(hightest_level)
                            if job_id not in hightest_level:
                                time_passed = self.time_passed(start_time)
                                if self.unusual_spider(name_of_spider=spider,
                                                       runtime_of_spider=time_passed,
                                                       save_to_database=False) > 0:
                                    self.terminator_log.info('Unusual spider detected! ')
                                    kill_lis.append(running_spider)
                                    if project and job_id:
                                        term = threading.Thread(target=self.kill_spider,
                                                                args=(project, job_id, spider, PID))
                                        term.setDaemon(True)
                                        term.start()
                                    else:
                                        p_name = '[project name] ' if not project else ''
                                        j_id = '[job id]' if not job_id else ''
                                        missing_data = p_name + j_id
                                        self.terminator_log.warn('Missing Target ID {}, Unable to Locate It!'.format(missing_data))
                                        pass
            except:
                self.terminator_log.warn("terminator ERROR")
                # break
            finally:
                self.terminator_log.warn('Scan completed')
                # self.terminator_log.warn('\t[- TERMINATOR -] >> Scan completed')
                time.sleep(self.terminator_scan_sep)

    def kill_spider(self, project, job_id, spider, PID):
        kill_url = os.path.join(self.server_port, 'cancel.json')
        self.terminator_log.warn('\n\n\tTarget Found! >>> {}  {}<<<\n'.format(spider, job_id))
        self.terminator_log.warn('terminate the spider "{}" within 3 seconds'.format(spider))
        time.sleep(2)
        self.terminator_log.warn('sending terminate signal...')
        body = {"project": project, "job": job_id}
        try:
            target_killed = False
            for _ in range(1, 2):
                res = json.loads(requests.post(url=kill_url, data=body).content)
                self.terminator_log.warn('terminate signal has been sanded [{}]'.format(_))
                kill_status = res.get('status')
                kill_prevstate = res.get('prevstate')
                if kill_status == 'ok' and kill_prevstate not in {'running', 'pending'}:
                    target_killed = True
                    break
                time.sleep(0.5)
            if target_killed:
                self.terminator_log.warn('Target [ {} ] has been terminated {}\n'.format(spider, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
                self.lock.acquire()
                self.db.add(model=TerminatedSpider, add_dic={'spider': spider, 'job_id': job_id})
                self.lock.release()
            else:
                raise ValueError('\t[- TERMINATOR -] >> Signal sended, but the target still running')
        except Exception as E:
            self.terminator_log.warn('sth goes wrong when sending the terminate signal : {}'.format(E))
            self.terminator_log.warn('trying to terminate it with PID...')
            try:
                os.kill(int(PID), signal.SIGKILL)
                self.lock.acquire()
                self.db.add(model=TerminatedSpider, add_dic={'spider': spider, 'job_id': job_id})
                self.lock.release()
                self.terminator_log.warn('Target [{}] has been terminated {}\n'.format(spider, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
            except:
                os.popen('taskkill.exe /pid:' + str(PID))
                self.lock.acquire()
                self.db.add(model=TerminatedSpider, add_dic={'spider': spider, 'job_id': job_id})
                self.lock.release()
                self.terminator_log.warn('Target [{}] has been terminated {}\n'.format(spider, time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))

    def time_passed(self, date_time):
        date_time = date_time.strip()
        if len(date_time.split(' ')) < 2:
            date_time = date_time + " 00:00:00"
        last_news_date = date_time.split(" ")[0].split('-')
        last_news_time = date_time.split(" ")[1].split(':')
        for t in last_news_time:
            last_news_date.append(t)
        ls = [int(x) if '.' not in x else int(float(x)) for x in last_news_date]
        secs = "(datetime.datetime.now() - " \
               "datetime.datetime({},{},{},{},{},{})).total_seconds()".format(ls[0], ls[1], ls[2], ls[3], ls[4], ls[5])
        secs = round(eval(secs))
        return secs
