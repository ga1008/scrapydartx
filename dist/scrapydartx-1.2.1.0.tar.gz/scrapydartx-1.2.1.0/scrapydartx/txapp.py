# this file is used to start scrapydartx with twistd -y
from scrapydartx import get_application
application = get_application()
